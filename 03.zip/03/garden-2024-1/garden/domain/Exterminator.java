package domain;
import java.awt.Color;
import java.util.Random;

public class Exterminator extends Agent implements Thing{ //Revisar movimiento en diagonal hacia abajo (se tpea)
    protected char nextState;
    protected Color color;
    private Garden garden;
    protected int row, column, targetRow, targetColumn;

    public Exterminator(Garden garden, int row, int column) {
        nextState = Agent.ALIVE;
        this.garden = garden;
        this.row = row;
        this.column = column;
        color = Color.blue;
        garden.setThing(row,column,(Thing)this);
    }
    
    
    /**
     * Let occurs a unit of time
     */
    public void act() {
        findTarget();
        boolean killed = killIfPossible();
        if(!killed){
            move();   
        }
    }
    
    /**
     * Find the closest flower
     */
    private void findTarget() {
        int minDistance = Integer.MAX_VALUE;
        int LENGTH = garden.getLength();
        boolean found = false;

        for (int r = 0; r < LENGTH; r++) {
            for (int c = 0; c < LENGTH; c++) {
                Thing thing = garden.getThing(r, c);
                if (thing instanceof Carnivorous) {
                    int distance = Math.abs(row - r) + Math.abs(column - c);
                    if (distance < minDistance) {
                        minDistance = distance;
                        targetRow = r;
                        targetColumn = c;
                    }
                    found = true;
                }
            }
        }
        
        if (found == false) {
            targetRow = row;
            targetColumn = column;
        }
    }
    
    /**
     * If its possible, eats the target Flower
     */
    private boolean killIfPossible() {
        if (Math.abs(row - targetRow) + Math.abs(column - targetColumn) ==1) {
            Carnivorous victim = (Carnivorous)garden.getThing(targetRow, targetColumn);
            int tempRow = victim.getRow(), tempColumn = victim.getColumn(), row0 = row, col0 = column;
            garden.setThing(targetRow, targetColumn, null);
            row = tempRow;
            column = tempColumn;
            garden.setThing(row, column, this);
            garden.setThing(row0, col0, null);
            return true;
        }
        else if (column != targetColumn && row != targetRow && Math.abs(row - targetRow) + Math.abs(column - targetColumn) == 2){
            Carnivorous victim = (Carnivorous)garden.getThing(targetRow, targetColumn);
            int tempRow = victim.getRow(), tempColumn = victim.getColumn(), row0 = row, col0 = column;
            garden.setThing(targetRow, targetColumn, null);
            row = tempRow;
            column = tempColumn;
            garden.setThing(row, column, this);
            garden.setThing(row0, col0, null);
            return true;
        }
        return false;
    }
    
    /**
     * Move the carnivorous to her targets position
     */
    public void move(){
        int dx = Integer.compare(targetColumn, column);
        int dy = Integer.compare(targetRow, row);
        int LENGTH = garden.getLength();

        int newRow = row + dy;
        int newColumn = column + dx;

        if (newRow >= 0 && newRow < LENGTH && newColumn >= 0 && newColumn < LENGTH) {
            if (garden.getThing(newRow, newColumn) == null) {
                garden.setThing(newRow, newColumn, this);
                garden.setThing(row, column, null);
                row = newRow;
                column = newColumn;
            }// ya veremos que pasa despues con este tipo de casos
        }
    }
    
    /**Returns the row
    @return 
     */
    public final int getRow(){
        return row;
    }

    /**Returns the column
    @return 
     */
    public final int getColumn(){
        return column;
    }
    
    /**Returns the color
    @return 
     */
    public Color getColor() {
        return color;
    }
    
    /**Returns the shape
    @return 
     */
    public int shape() {
        return Thing.ROUND;
    }
}
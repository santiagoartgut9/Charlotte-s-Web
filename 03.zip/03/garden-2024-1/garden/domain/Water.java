package domain;

public final class Water  implements Thing{
    public void act(){
    }
}

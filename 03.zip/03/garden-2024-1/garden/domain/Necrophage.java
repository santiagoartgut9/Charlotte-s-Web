package domain;
import java.awt.Color;
// Para tener en cuenta: Existe un método Flor.isAlive();
/**Information about a Carnivorous<br>
<b>(garden,row,column,time,state,nextState, color)</b><br>
<br>
 */
public class Necrophage extends Agent implements Thing {
    protected char nextState;
    protected Color color;
    private Garden garden;
    protected int row, column, targetRow, targetColumn;
    
    
    /**Create a new carnovorous (<b>row,column</b>) in the garden <b>garden</b>.
     * Every new Carnivorous is going to be alive in the following state.
     * @param garden 
     * @param row 
     * @param column 
     */
    public Necrophage(Garden garden, int row, int column) {
        this.garden=garden;
        this.row = row;
        this.column = column;
        color = Color.GREEN;
        garden.setThing(row,column,(Thing)this);  
        nextState = ALIVE;
    }
    
    /**
     * Let occurs a unit of time
     */
    public void act() {
        findTarget();
        boolean eaten = eatIfPossible();
        if(!eaten){
            move();   
        }
    }
    
    /**
     * Find the closest flower
     */
    private void findTarget() {
        int minDistance = Integer.MAX_VALUE;
        int LENGTH = garden.getLength();
        boolean found = false;

        for (int r = 0; r < LENGTH; r++) {
            for (int c = 0; c < LENGTH; c++) {
                Thing thing = garden.getThing(r, c);
                if (thing instanceof Flower && ((Flower)thing).isDead()) {
                    int distance = Math.abs(row - r) + Math.abs(column - c);
                    if (distance < minDistance) {
                        minDistance = distance;
                        targetRow = r;
                        targetColumn = c;
                    }
                    found = true;
                }
            }
        }
        
        if (found == false) {
            targetRow = row;
            targetColumn = column;
        }
    }
    
    /**
     * If its possible, eats the target Flower
     */
    private boolean eatIfPossible() {
        if (Math.abs(row - targetRow) + Math.abs(column - targetColumn) ==1) {
            Flower victim = (Flower)garden.getThing(targetRow, targetColumn);
            if(victim.isDead()){
                int tempRow = victim.getRow(), tempColumn = victim.getColumn(), row0 = row, col0 = column;
                garden.setThing(targetRow, targetColumn, null);
                row = tempRow;
                column = tempColumn;
                garden.setThing(row, column, this);
                garden.setThing(row0, col0, null);
                return true;
            }
        }
        else if (column != targetColumn && row != targetRow && Math.abs(row - targetRow) + Math.abs(column - targetColumn) == 2){
            Flower victim = (Flower)garden.getThing(targetRow, targetColumn);
            if(victim.isDead()){
                int tempRow = victim.getRow(), tempColumn = victim.getColumn(), row0 = row, col0 = column;
                garden.setThing(targetRow, targetColumn, null);
                row = tempRow;
                column = tempColumn;
                garden.setThing(row, column, this);
                garden.setThing(row0, col0, null);
                return true;
            }
        }
        return false;
    }
    
    /**
     * Move the carnivorous to her targets position
     */
    public void move(){
        int dx = Integer.compare(targetColumn, column);
        int dy = Integer.compare(targetRow, row);
        int LENGTH = garden.getLength();

        int newRow = row + dy;
        int newColumn = column + dx;

        if (newRow >= 0 && newRow < LENGTH && newColumn >= 0 && newColumn < LENGTH) {
            if (garden.getThing(newRow, newColumn) == null) {
                garden.setThing(newRow, newColumn, this);
                garden.setThing(row, column, null);
                row = newRow;
                column = newColumn;
            }// ya veremos que pasa despues con este tipo de casos
        }
    }
    
    /**Returns the row
    @return 
     */
    public final int getRow(){
        return row;
    }

    /**Returns the column
    @return 
     */
    public final int getColumn(){
        return column;
    }
    
    /**Returns the color
    @return 
     */
    public Color getColor() {
        return color;
    }
    
    /**Returns the shape
    @return 
     */
    public int shape() {
        return Thing.FLOWER;
    }
}

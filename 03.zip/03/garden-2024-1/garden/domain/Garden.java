package domain;
import java.util.*;


/*No olviden adicionar la documentacion*/
public class Garden{
    static public int LENGTH=40;
    private Thing[][] garden;
    
    public Garden() {
        garden=new Thing[LENGTH][LENGTH];
        for (int r=0;r<LENGTH;r++){
            for (int c=0;c<LENGTH;c++){
                garden[r][c]=null;
            }
        }
        setThing(0,0,new Water());
        for (int i=1;i<5;i++){
            for (int j=1;j<5;j++){
                setThing(LENGTH-i,LENGTH-j,new Water());
            }
        }
        someThings();
    }

    public int  getLength(){
        return LENGTH;
    }

    public Thing getThing(int r,int c){
        return garden[r][c];
    }

    public void setThing(int r, int c, Thing e){
        garden[r][c]=e;
    }

    public void someThings(){
        Flower rose = new Flower(this, 10, 10);
        Flower violet = new Flower(this, 15, 15);
        Carnivorous venus = new Carnivorous(this, 20, 20);
        Carnivorous sundeuos = new Carnivorous(this, 15, 17);
        //Flower example = new Flower(this, 30, 25);
        Necrophage sebastian = new Necrophage(this, 30, 30);
        Necrophage santiago = new Necrophage(this, 33, 25);
        Exterminator prueba = new Exterminator(this, 23, 23);
    }
    
    /**
     * Makes a tic-tac on the garden
     */
    public void ticTac(){
        for (int r = 0; r < LENGTH; r++){
            for (int c = 0; c < LENGTH; c++){
                Thing thing = getThing(r, c);
                if (thing instanceof Flower){
                    Flower flower = (Flower) thing;
                    flower.act();
                }
                else if (thing instanceof Carnivorous){
                    Carnivorous flower = (Carnivorous) thing;
                    flower.act();
                }
                else if (thing instanceof Necrophage){
                    Necrophage flower = (Necrophage) thing;
                    flower.act();
                }
                else if (thing instanceof Exterminator){
                    Exterminator man = (Exterminator) thing;
                    man.act();
                }
            }
        }
    }
}

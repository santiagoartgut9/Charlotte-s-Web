package test;
import domain.*;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;


/**
 * The test class UnitTests.
 *
 * @author  Sebastian Galvis
 * @author  Santiago Arteaga
 * @version March 23
 */
public class UnitTests {
    
    @Test
    public void shouldEatDeadFlowers(){
        Garden garden = new Garden();
        Flower flowerToBeEaten = new Flower(garden, 10, 10);
        Necrophage necrophageToBeHunter = new Necrophage(garden, 10, 11);
        assertTrue(garden.getThing(10, 10) instanceof Flower);
        garden.ticTac();
        assertTrue(garden.getThing(10, 10) instanceof Flower);
        garden.ticTac();
        assertTrue(garden.getThing(10, 10) instanceof Flower);
        garden.ticTac(); // Al tercer Tic-tac ya es comestible
        assertTrue(garden.getThing(10, 10) instanceof Necrophage);
    }
    
    @Test
    public void shouldWalkToDeadFlowers(){
        Garden garden = new Garden();
        Flower flowerToBeEaten = new Flower(garden, 10, 10);
        Necrophage necrophageToBeHunter = new Necrophage(garden, 10, 12);
        garden.ticTac();
        garden.ticTac();
        garden.ticTac();
        assertTrue(garden.getThing(10, 11) instanceof Necrophage);
    }
    
    @Test
    public void santiagoSebastianSituation(){
        Garden garden = new Garden();
        Flower example = new Flower(garden, 30, 25);
        Necrophage sebastian = new Necrophage(garden, 30, 30);
        Necrophage santiago = new Necrophage(garden, 33, 25);
        garden.ticTac();
        garden.ticTac();
        garden.ticTac();
        garden.ticTac();
        garden.ticTac();
        garden.ticTac();
        assertEquals(santiago.getRow(), 30);
        assertEquals(santiago.getColumn(), 25);
        assertEquals(sebastian.getRow(), 30);
        assertEquals(sebastian.getColumn(), 27);
    }
}
